class AttendsController < ApplicationController
end
