FactoryGirl.define do
  factory :attend do
    user nil
    event nil
  end
end
