FactoryGirl.define do
  factory :event do
    name "MyString"
    date "2017-10-18"
    city "MyString"
    state "MyString"
  end
end
