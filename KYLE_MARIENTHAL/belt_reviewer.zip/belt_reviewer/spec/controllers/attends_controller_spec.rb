require 'rails_helper'

RSpec.describe AttendsController, type: :controller do

end
