class DojosController < ApplicationController
  def index
    @dojos = Dojo.all
  end

  def new
  end

  def create
    @dojo = Dojo.create(dojo_params)
    if @dojo.valid?
      flash[:notice] = "You have successfully created a Dojo!"
      return redirect_to root_path
    else
      flash[:errors] = @dojo.errors.full_messages
      return redirect_to :back
    # redirect_to root_path
    end
  end

  def show
    @dojo = Dojo.find(params[:id])
  end

  def edit
    @dojo = Dojo.find(params[:id])
  end

  def delete
    Dojo.find(params[:id]).delete
    return redirect_to :back
  end
  def update
    @dojo = Dojo.update(params[:id], dojo_params)

    return redirect_to dojos_show_path
  end

private
  def dojo_params
    params.require(:dojo).permit(:branch, :street, :city, :state)
  end
end
