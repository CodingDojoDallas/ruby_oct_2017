class Group < ActiveRecord::Base
  belongs_to :user
  has_many :connects
  has_many :connectors, through: :connects, source :user
end
