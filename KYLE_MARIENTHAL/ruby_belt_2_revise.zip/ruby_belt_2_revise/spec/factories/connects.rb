FactoryGirl.define do
  factory :connect do
    user nil
    group nil
  end
end
