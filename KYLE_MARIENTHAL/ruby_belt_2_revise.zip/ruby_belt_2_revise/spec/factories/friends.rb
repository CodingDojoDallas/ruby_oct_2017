FactoryGirl.define do
  factory :friend do
    user nil
    friendee nil
  end
end
